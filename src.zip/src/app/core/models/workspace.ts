export interface Workspace {}
